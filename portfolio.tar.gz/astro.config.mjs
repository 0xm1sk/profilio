{
  "site": "static",
  "base": "/portfolio"
}
